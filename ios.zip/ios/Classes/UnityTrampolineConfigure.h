#pragma once

// Auto Generated File, do not edit!
// It will be updated whenever we update unity version
// When unity version is changed:
//   UNITY_VERSION value will be changed
//   UNITY_X_Y_Z for this new version will be added

#define UNITY_VERSION 431

// known unity versions
#define UNITY_4_2_0 420
#define UNITY_4_2_1 421
#define UNITY_4_2_2 422
#define UNITY_4_3_0 430
#define UNITY_4_3_1 431
